import re
from flask import *
import sqlite3
from datetime import date
app = Flask(__name__)

entryContent = ""
entryTitle = ""
entryDate = ""

@app.route('/')
def main():
    connection = sqlite3.connect('DataBaseUwU.db')
    cur = connection.cursor()

    HTMLTitle = cur.execute("SELECt titre FROm article").fetchall()
    HTMLText = cur.execute("SELECt contenu FROm article").fetchall()
    HTMLDate = cur.execute("SELECt date FROm article").fetchall()
    HTMLArticles = cur.execute("SELECt * FROm article").fetchall()
    Bruh = cur.execute("SELECt id_article FROm article").fetchall()

    connection.commit()
    return render_template('index.html', HTMLTitle = HTMLTitle , HTMLText = HTMLText , HTMLArticles = range(len(HTMLArticles)) , HTMLDate = HTMLDate , hELP = Bruh)

@app.route('/', methods=['POST'])
def mainPost():
    connection = sqlite3.connect('DataBaseUwU.db')
    cur = connection.cursor()

    HTMLTitle = cur.execute("SELECt titre FROm article").fetchall()
    HTMLText = cur.execute("SELECt contenu FROm article").fetchall()
    HTMLDate = cur.execute("SELECt date FROm article").fetchall()
    HTMLArticles = cur.execute("SELECt * FROm article").fetchall()
    Bruh = cur.execute("SELECt id_article FROm article").fetchall()

    connection.commit()
    if request.method == "POST":
        id = int(request.form.get("test"))
        print(id)
    return render_template('articles.html', HTMLTitle = HTMLTitle , HTMLText = HTMLText , HTMLArticles = range(len(HTMLArticles)) , HTMLDate = HTMLDate , hELP = Bruh , id = id)

@app.route("/inscription")
def inscription():
    return render_template("inscription.html", verification = 0)

@app.route("/inscription", methods=['POST'])
def inscriptionPost():
    connection = sqlite3.connect('DataBaseUwU.db')
    cur = connection.cursor()
    entryName = request.form['nom']
    entryMail = request.form['adresse_mail']
    entryPassword = request.form['mot_de_passe']
    test = cur.execute("SELECt nom FROm utilisateur").fetchall()
    if len(test) != 0:
        for x in range(len(test)):
            if test[x][0] == entryName:
                print("same")
                return render_template("inscription.html", verification = 2)
    else:
        return render_template("inscription.html", verification = 3)
    if (len(entryMail)==0):
        return render_template("inscription.html", verification = 4)
    if (len(entryPassword)<8):
        return render_template("inscription.html", verification = 5)
    elif not re.search("[a-z]",entryPassword):
        return render_template("inscription.html", verification = 6)
    elif not re.search("[A-Z]",entryPassword):
        return render_template("inscription.html", verification = 7)
    elif not re.search("[0-9]",entryPassword):
        return render_template("inscription.html", verification = 8)
    elif not re.search("[@_!#$%^&*()<>?/|}{~:]", entryPassword):
        return render_template("inscription.html", verification = 9)

    cur.execute("INSERt INTo utilisateur (nom, adresse_mail, mot_de_passe) VALUES (?, ?, ?)",(entryName, entryMail,entryPassword))
    connection.commit()
    connection.close()
    return render_template("index.html", verification = 1)

@app.route("/article")
def article():
    return render_template("articles.html")

@app.route("/creation_article")
def creationArticle():
    return render_template("creation_article.html")

@app.route("/creation_article", methods=['POST'])
def creationArticlePost():
    global entryTitle
    global entryContent
    global entryDate
    connection = sqlite3.connect('DataBaseUwU.db')
    cur = connection.cursor()
    entryTitle = request.form['nom_article']
    entryContent = request.form['contenu']
    entryDate = date.today()
    print(entryContent,entryDate,entryTitle)
    cur.execute("INSERT INTO article (titre, contenu, date) VALUES (?, ?, ?)",(entryTitle, entryContent, entryDate))
    connection.commit()
    connection.close()
    return redirect(url_for('main'))

app.run()